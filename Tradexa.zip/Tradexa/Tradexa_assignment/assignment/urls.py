from django.urls import path
from .views import insert_data

urlpatterns = [
    path('insert-data/', insert_data, name='insert_data'),
]